const ms = require('ms');
module.exports = { ms };