const Filter = require('bad-words');
const fs = require('fs');
const config = require('../config.json');
const { sendModLog } = require('./modlog');
const { baseEmbed } = require('./embed');
const ms = require('ms');

const filter = new Filter();
const messageCache = new Map();

function isInvite(message) {
  const inviteRegex = /(https?:\/\/)?(www\.)?(discord\.gg|discordapp\.com\/invite)\/[A-Za-z0-9]+/i;
  return inviteRegex.test(message.content);
}
function hasLink(message) {
  const urlRegex = /(https?:\/\/[^\s]+)/i;
  return urlRegex.test(message.content);
}

async function handleMessage(client, message) {
  if (!message.guild || message.author.bot) return;
  const guildId = message.guild.id;
  const cfg = config;

  if (cfg.badWords.enabled) {
    if (filter.isProfane(message.content)) {
      await message.delete().catch(()=>{});
      await message.channel.send({ embeds: [baseEmbed().setTitle('AutoMod').setDescription(`${message.author} pesan dihapus: mengandung kata terlarang.`)] }).then(m=>setTimeout(()=>m.delete().catch(()=>{}),5000));
      await sendModLog(message.guild, client, 'Message Deleted (Bad Word)', `${message.author.tag} sent a forbidden word`, [{ name:'Content', value: message.content.slice(0,1024) }]);
      return;
    }
  }

  if (cfg.antiInvite.enabled && isInvite(message)) {
    await message.delete().catch(()=>{});
    await message.channel.send({ embeds: [baseEmbed().setTitle('AutoMod').setDescription(`${message.author} invitation link terdeteksi — dihapus.`)] }).then(m=>setTimeout(()=>m.delete().catch(()=>{}),5000));
    await sendModLog(message.guild, client, 'Invite Deleted', `${message.author.tag} posted an invite.`, [{ name:'Content', value: message.content.slice(0,1024) }]);
    return;
  }

  if (cfg.antiLinks.enabled && hasLink(message)) {
    await message.delete().catch(()=>{});
    await message.channel.send({ embeds: [baseEmbed().setTitle('AutoMod').setDescription(`${message.author} link terdeteksi — dihapus.`)] }).then(m=>setTimeout(()=>m.delete().catch(()=>{}),5000));
    await sendModLog(message.guild, client, 'Link Deleted', `${message.author.tag} posted a link.`, [{ name:'Content', value: message.content.slice(0,1024) }]);
    return;
  }

  if (cfg.antiCaps.enabled && message.content.length >= cfg.antiCaps.minLength) {
    const letters = message.content.replace(/[^A-Za-z]/g,'');
    if (letters.length) {
      const caps = letters.split('').filter(c => c === c.toUpperCase()).length;
      const ratio = caps / letters.length;
      if (ratio >= cfg.antiCaps.threshold) {
        await message.delete().catch(()=>{});
        await message.channel.send({ embeds: [baseEmbed().setTitle('AutoMod').setDescription(`${message.author} pesan dihapus: CAPS excessive.`)] }).then(m=>setTimeout(()=>m.delete().catch(()=>{}),5000));
        await sendModLog(message.guild, client, 'Message Deleted (Caps)', `${message.author.tag} used excessive caps`, [{ name:'Content', value: message.content.slice(0,1024) }]);
        return;
      }
    }
  }

  if (cfg.antiSpam.enabled) {
    const now = Date.now();
    const key = `${guildId}_${message.author.id}`;
    const record = messageCache.get(key) || { msgs: [], lastMsg: 0 };
    record.msgs = record.msgs.filter(t => now - t <= cfg.antiSpam.intervalSeconds * 1000);
    record.msgs.push(now);
    record.lastMsg = now;
    messageCache.set(key, record);

    if (record.msgs.length >= cfg.antiSpam.messages) {
      const action = cfg.antiSpam.action;
      const durationRaw = cfg.antiSpam.actionDuration;

      if (action === 'mute') {
        let muteRole = message.guild.roles.cache.find(r => r.name === 'Muted');
        if (!muteRole) {
          try {
            muteRole = await message.guild.roles.create({ name: 'Muted', permissions: [] });
            for (const channel of message.guild.channels.cache.values()) {
              await channel.permissionOverwrites.edit(muteRole, { SendMessages:false, AddReactions:false, Speak:false });
            }
          } catch(e) { console.error('Failed to create muted role', e); }
        }
        try {
          const member = message.member;
          await member.roles.add(muteRole, 'Auto-mute for spam');
          const until = durationRaw ? Date.now() + ms(durationRaw) : null;
          const path = './database/mutes.json';
          let mutes = {};
          if (fs.existsSync(path)) mutes = JSON.parse(fs.readFileSync(path));
          mutes[member.id] = { guildId: message.guild.id, until };
          fs.writeFileSync(path, JSON.stringify(mutes, null, 2));
          await sendModLog(message.guild, client, 'Auto Mute (Spam)', `${member.user.tag} auto-muted for spam`, [{ name:'Count', value: `${record.msgs.length}` }]);
        } catch(e) { console.error(e); }
      } else if (action === 'kick') {
        try { await message.member.kick('Auto-kicked for spam'); await sendModLog(message.guild, client, 'Auto Kick (Spam)', `${message.author.tag} kicked for spam`); } catch(e) {}
      } else if (action === 'ban') {
        try { await message.member.ban({ reason:'Auto-ban for spam' }); await sendModLog(message.guild, client, 'Auto Ban (Spam)', `${message.author.tag} banned for spam`); } catch(e) {}
      }

      messageCache.delete(key);
      await message.channel.send({ embeds: [baseEmbed().setTitle('AutoMod').setDescription(`${message.author} tindakan otomatis dipicu untuk spam.`)] }).then(m=>setTimeout(()=>m.delete().catch(()=>{}),5000));
      return;
    }
  }

  if (config.antiFlood.enabled) {
    const recent = (messageCache.get(`${guildId}_${message.author.id}`) || { msgs: [] }).msgs || [];
    if (recent.length > config.antiFlood.lines) {
      await message.delete().catch(()=>{});
      await sendModLog(message.guild, client, 'Auto Delete (Flood)', `${message.author.tag} possible flood`);
      return;
    }
  }
}

module.exports = { handleMessage };
