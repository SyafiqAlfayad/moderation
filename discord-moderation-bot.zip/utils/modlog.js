const { baseEmbed } = require('./embed');
const config = require('../config.json');

async function sendModLog(guild, client, title, description, fields = []) {
  try {
    const channel = guild.channels.cache.get(config.modLogChannelId);
    if (!channel) return;
    const embed = baseEmbed()
      .setTitle(title)
      .setDescription(description);
    if (fields && fields.length) embed.addFields(fields);
    await channel.send({ embeds: [embed] });
  } catch (err) {
    console.error('Failed to send mod log:', err);
  }
}
module.exports = { sendModLog };
