const { EmbedBuilder } = require('discord.js');
function baseEmbed() {
  return new EmbedBuilder()
    .setColor('#5865F2')
    .setTimestamp()
    .setFooter({ text: 'Moderation Bot by Syafiq' });
}
module.exports = { baseEmbed };
