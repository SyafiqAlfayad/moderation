const fs = require('fs');
const { baseEmbed } = require('../../utils/embed');

module.exports = {
  name: 'warnings',
  description: 'Show warnings',
  async execute({ client, message, args }) {
    const warnsPath = './database/warns.json';
    const warns = fs.existsSync(warnsPath) ? JSON.parse(fs.readFileSync(warnsPath)) : {};
    const user = message.mentions.users.first() || message.guild.members.cache.get(args[0])?.user || message.author;

    const userWarns = warns[user.id] || [];
    if (!userWarns.length) return message.reply({ embeds: [baseEmbed().setTitle('No Warnings').setDescription(`${user.tag} tidak memiliki peringatan.`)] });

    const embed = baseEmbed().setTitle('Warnings').setDescription(`${user.tag} memiliki ${userWarns.length} peringatan.`);
    for (let i = 0; i < userWarns.length; i++) {
      const w = userWarns[i];
      embed.addFields({ name:`#${i+1}`, value: `By: <@${w.by}> | Reason: ${w.reason} | ${new Date(w.time).toLocaleString()}` });
    }
    await message.reply({ embeds: [embed] });
  }
};
