const fs = require('fs');
const { baseEmbed } = require('../../utils/embed');
const { sendModLog } = require('../../utils/modlog');

module.exports = {
  name: 'unmute',
  description: 'Unmute a member',
  async execute({ client, message, args }) {
    if (!message.member.permissions.has('ModerateMembers')) return message.reply({ embeds: [baseEmbed().setTitle('Permission Denied').setDescription('Kamu tidak punya izin untuk unmute.')] });
    const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!target) return message.reply({ embeds: [baseEmbed().setTitle('Usage').setDescription('!unmute @user')] });

    const muteRole = message.guild.roles.cache.find(r => r.name === 'Muted');
    if (!muteRole) return message.reply({ embeds: [baseEmbed().setTitle('Not Muted').setDescription('Tidak ada role Muted di server.')] });
    await target.roles.remove(muteRole);

    const path = './database/mutes.json';
    if (fs.existsSync(path)) {
      const data = JSON.parse(fs.readFileSync(path));
      if (data[target.id]) {
        delete data[target.id];
        fs.writeFileSync(path, JSON.stringify(data, null, 2));
      }
    }

    await message.reply({ embeds: [baseEmbed().setTitle('Unmuted').setDescription(`${target.user.tag} sudah tidak dibisukan lagi.`)] });
    await sendModLog(message.guild, client, 'User Unmuted', `${target.user.tag} (${target.id})`, [{ name:'By', value: message.author.tag }]);
  }
};
