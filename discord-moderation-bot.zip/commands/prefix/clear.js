const { baseEmbed } = require('../../utils/embed');
module.exports = {
  name: 'clear',
  description: 'Clear messages',
  async execute({ client, message, args }) {
    if (!message.member.permissions.has('ManageMessages')) return message.reply({ embeds: [baseEmbed().setTitle('Permission Denied').setDescription('Kamu tidak punya izin menghapus pesan.')] });
    const amount = Math.min(100, parseInt(args[0])) || 10;
    const deleted = await message.channel.bulkDelete(amount, true).catch(()=>null);
    await message.reply({ embeds: [baseEmbed().setTitle('Cleared').setDescription(`Dihapus: ${deleted?.size || 0} pesan.`)] }).then(m => setTimeout(()=>m.delete().catch(()=>{}),5000));
  }
};
