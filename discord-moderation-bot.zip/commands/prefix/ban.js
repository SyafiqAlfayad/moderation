const { baseEmbed } = require('../../utils/embed');
const { sendModLog } = require('../../utils/modlog');

module.exports = {
  name: 'ban',
  description: 'Ban a member',
  async execute({ client, message, args }) {
    if (!message.member.permissions.has('BanMembers')) return message.reply({ embeds: [baseEmbed().setTitle('Permission Denied').setDescription('Kamu tidak punya izin Ban Members.')] });
    const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    const reason = args.slice(1).join(' ') || 'No reason provided';
    if (!target) return message.reply({ embeds: [baseEmbed().setTitle('Usage').setDescription('!ban @user [reason]')] });
    if (!target.bannable) return message.reply({ embeds: [baseEmbed().setTitle('Cannot Ban').setDescription('Bot tidak bisa memban user ini.')] });

    await target.ban({ reason });
    await message.reply({ embeds: [baseEmbed().setTitle('Banned').setDescription(`${target.user.tag} telah diban.`).addFields({ name: 'Reason', value: reason })] });
    await sendModLog(message.guild, client, 'User Banned', `${target.user.tag} (${target.id})`, [{ name:'By', value: message.author.tag }, { name:'Reason', value: reason }]);
  }
};
