const { baseEmbed } = require('../../utils/embed');
module.exports = {
  name: 'userinfo',
  description: 'Show user info',
  async execute({ client, message, args }) {
    const user = message.mentions.users.first() || message.guild.members.cache.get(args[0])?.user || message.author;
    const member = await message.guild.members.fetch(user.id).catch(()=>null);
    const embed = baseEmbed().setTitle(`${user.tag}`).setThumbnail(user.displayAvatarURL());
    if (member) embed.addFields({ name:'Joined', value: `${new Date(member.joinedTimestamp).toLocaleString()}` });
    embed.addFields({ name:'ID', value:`${user.id}` });
    await message.reply({ embeds:[embed] });
  }
};
