const fs = require('fs');
const { baseEmbed } = require('../../utils/embed');
const { sendModLog } = require('../../utils/modlog');

const warnsPath = './database/warns.json';
let warns = {};
if (fs.existsSync(warnsPath)) warns = JSON.parse(fs.readFileSync(warnsPath));

module.exports = {
  name: 'warn',
  description: 'Warn a member',
  async execute({ client, message, args }) {
    if (!message.member.permissions.has('ManageMessages')) return message.reply({ embeds: [baseEmbed().setTitle('Permission Denied').setDescription('Kamu tidak punya izin memberi warning.')] });
    const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    const reason = args.slice(1).join(' ') || 'No reason provided';
    if (!target) return message.reply({ embeds: [baseEmbed().setTitle('Usage').setDescription('!warn @user [reason]')] });

    if (!warns[target.id]) warns[target.id] = [];
    warns[target.id].push({ by: message.author.id, reason, time: Date.now() });
    fs.writeFileSync(warnsPath, JSON.stringify(warns, null, 2));

    await message.reply({ embeds: [baseEmbed().setTitle('Warned').setDescription(`${target.user.tag} telah diberi peringatan.`).addFields({ name:'Reason', value: reason })] });
    await sendModLog(message.guild, client, 'User Warned', `${target.user.tag} (${target.id})`, [{ name:'By', value: message.author.tag }, { name:'Reason', value: reason }]);
  }
};
