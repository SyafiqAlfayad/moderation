const { baseEmbed } = require('../../utils/embed');
module.exports = {
  name: 'avatar',
  description: 'Show avatar',
  async execute({ client, message, args }) {
    const user = message.mentions.users.first() || message.guild.members.cache.get(args[0])?.user || message.author;
    const embed = baseEmbed().setTitle(`${user.tag} Avatar`).setImage(user.displayAvatarURL({size:1024}));
    await message.reply({ embeds:[embed] });
  }
};
