const { baseEmbed } = require('../../utils/embed');
module.exports = {
  name: 'slowmode',
  description: 'Set slowmode (seconds)',
  async execute({ client, message, args }) {
    if (!message.member.permissions.has('ManageChannels')) return message.reply({ embeds: [baseEmbed().setTitle('Permission Denied').setDescription('Kamu tidak punya izin mengatur slowmode.')] });
    const seconds = Math.max(0, Math.min(21600, parseInt(args[0]) || 0));
    await message.channel.setRateLimitPerUser(seconds);
    await message.reply({ embeds: [baseEmbed().setTitle('Slowmode Set').setDescription(`Slowmode diatur ke ${seconds} detik.`)] });
  }
};
