const { baseEmbed } = require('../../utils/embed');
module.exports = {
  name: 'ping',
  description: 'Check bot latency',
  async execute({ client, message }) {
    const sent = await message.reply({ embeds: [baseEmbed().setTitle('Pinging...').setDescription('Mengukur latency...')] });
    const latency = sent.createdTimestamp - message.createdTimestamp;
    await sent.edit({ embeds: [baseEmbed().setTitle('Pong!').addFields({ name:'Latency', value: `${latency}ms` }, { name:'WS', value: `${client.ws.ping}ms` })] });
  }
};
