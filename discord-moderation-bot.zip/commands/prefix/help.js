const { baseEmbed } = require('../../utils/embed');
module.exports = {
  name: 'help',
  description: 'Show help',
  async execute({ client, message }) {
    const embed = baseEmbed().setTitle('Help').setDescription('Daftar perintah: !ban !kick !mute !unmute !warn !warnings !clear !slowmode !ping !userinfo !serverinfo !avatar !help');
    await message.reply({ embeds:[embed] });
  }
};
