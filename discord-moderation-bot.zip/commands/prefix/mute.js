const fs = require('fs');
const { baseEmbed } = require('../../utils/embed');
const { ms } = require('../../utils/time');
const { sendModLog } = require('../../utils/modlog');

const mutesPath = './database/mutes.json';
let mutes = {};
if (fs.existsSync(mutesPath)) mutes = JSON.parse(fs.readFileSync(mutesPath));

module.exports = {
  name: 'mute',
  description: 'Mute a member',
  async execute({ client, message, args }) {
    if (!message.member.permissions.has('ModerateMembers')) return message.reply({ embeds: [baseEmbed().setTitle('Permission Denied').setDescription('Kamu tidak punya izin untuk mute.')] });
    const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!target) return message.reply({ embeds: [baseEmbed().setTitle('Usage').setDescription('!mute @user [duration] [reason]')] });
    const rawDuration = args[1] || client.config.defaultMuteDuration;
    const durationMs = ms(rawDuration);
    const reason = args.slice(2).join(' ') || 'No reason provided';

    let muteRole = message.guild.roles.cache.find(r => r.name === 'Muted');
    if (!muteRole) {
      muteRole = await message.guild.roles.create({ name: 'Muted', permissions: [] });
      for (const channel of message.guild.channels.cache.values()) {
        await channel.permissionOverwrites.edit(muteRole, { SendMessages: false, AddReactions: false, Speak: false });
      }
    }

    await target.roles.add(muteRole, reason);
    const until = durationMs ? Date.now() + durationMs : null;

    mutes[target.id] = { guildId: message.guild.id, until };
    fs.writeFileSync(mutesPath, JSON.stringify(mutes, null, 2));

    await message.reply({ embeds: [baseEmbed().setTitle('Muted').setDescription(`${target.user.tag} dibisukan.`).addFields({ name:'Duration', value: rawDuration || 'permanent' }, { name:'Reason', value: reason })] });
    await sendModLog(message.guild, client, 'User Muted', `${target.user.tag} (${target.id})`, [{ name:'By', value: message.author.tag }, { name:'Duration', value: rawDuration }, { name:'Reason', value: reason }]);

    if (durationMs) setTimeout(async () => {
      try {
        const member = await message.guild.members.fetch(target.id).catch(()=>null);
        if (member) {
          await member.roles.remove(muteRole, 'Auto unmute');
          delete mutes[target.id];
          fs.writeFileSync(mutesPath, JSON.stringify(mutes, null, 2));
          await sendModLog(message.guild, client, 'Auto Unmuted', `${target.user.tag} (${target.id})`, [{ name:'Reason', value: 'Mute duration expired' }]);
        }
      } catch (err) { console.error(err); }
    }, durationMs);
  }
};
