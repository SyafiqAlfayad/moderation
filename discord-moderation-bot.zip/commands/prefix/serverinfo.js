const { baseEmbed } = require('../../utils/embed');
module.exports = {
  name: 'serverinfo',
  description: 'Show server info',
  async execute({ client, message }) {
    const g = message.guild;
    const embed = baseEmbed().setTitle(`${g.name} Info`).addFields(
      { name:'Members', value: `${g.memberCount}`, inline:true },
      { name:'Owner', value: `<@${g.ownerId}>`, inline:true },
      { name:'ID', value:`${g.id}`, inline:true }
    );
    await message.reply({ embeds:[embed] });
  }
};
