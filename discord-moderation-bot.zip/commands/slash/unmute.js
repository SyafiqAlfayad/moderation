const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
const { baseEmbed } = require('../../utils/embed');
const { sendModLog } = require('../../utils/modlog');

module.exports = {
  data: new SlashCommandBuilder().setName('unmute').setDescription('Unmute a user').addUserOption(o=>o.setName('user').setDescription('Target').setRequired(true)),
  async execute({ client, interaction }) {
    if (!interaction.member.permissions.has('ModerateMembers')) return interaction.reply({ ephemeral:true, embeds:[baseEmbed().setTitle('Permission Denied').setDescription('Kamu tidak punya izin untuk unmute.')] });
    const user = interaction.options.getUser('user');
    const member = interaction.guild.members.cache.get(user.id);
    if (!member) return interaction.reply({ ephemeral:true, embeds:[baseEmbed().setTitle('Not found').setDescription('Member tidak ditemukan.')] });

    const muteRole = interaction.guild.roles.cache.find(r => r.name === 'Muted');
    if (!muteRole) return interaction.reply({ ephemeral:true, embeds:[baseEmbed().setTitle('Not Muted').setDescription('Tidak ada role Muted di server.')] });
    await member.roles.remove(muteRole);

    const path = './database/mutes.json';
    if (fs.existsSync(path)) {
      const data = JSON.parse(fs.readFileSync(path));
      if (data[member.id]) { delete data[member.id]; fs.writeFileSync(path, JSON.stringify(data, null, 2)); }
    }

    await interaction.reply({ embeds: [baseEmbed().setTitle('Unmuted').setDescription(`${user.tag} sudah tidak dibisukan lagi.`)] });
    await sendModLog(interaction.guild, client, 'User Unmuted', `${user.tag} (${user.id})`, [{ name:'By', value: interaction.user.tag }]);
  }
};
