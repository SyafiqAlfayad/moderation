const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../../utils/embed');
module.exports = {
  data: new SlashCommandBuilder().setName('ping').setDescription('Check bot latency'),
  async execute({ client, interaction }) {
    const embed = baseEmbed().setTitle('Pong!').addFields({ name:'WS', value:`${client.ws.ping}ms` });
    await interaction.reply({ embeds:[embed] });
  }
};
