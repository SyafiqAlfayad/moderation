const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../../utils/embed');
const { sendModLog } = require('../../utils/modlog');

module.exports = {
  data: new SlashCommandBuilder().setName('kick').setDescription('Kick a user').addUserOption(o=>o.setName('user').setDescription('Target').setRequired(true)).addStringOption(o=>o.setName('reason').setDescription('Reason')),
  async execute({ client, interaction }) {
    if (!interaction.member.permissions.has('KickMembers')) return interaction.reply({ ephemeral:true, embeds:[baseEmbed().setTitle('Permission Denied').setDescription('Kamu tidak punya izin Kick Members.')] });
    const user = interaction.options.getUser('user');
    const member = interaction.guild.members.cache.get(user.id);
    const reason = interaction.options.getString('reason') || 'No reason provided';
    if (!member) return interaction.reply({ ephemeral:true, embeds:[baseEmbed().setTitle('Not found').setDescription('Member tidak ditemukan.')] });
    if (!member.kickable) return interaction.reply({ ephemeral:true, embeds:[baseEmbed().setTitle('Cannot Kick').setDescription('Bot tidak bisa mengkick user ini.')] });
    await member.kick(reason);
    await interaction.reply({ embeds: [baseEmbed().setTitle('Kicked').setDescription(`${user.tag} telah dikick.`).addFields({ name:'Reason', value:reason })] });
    await sendModLog(interaction.guild, client, 'User Kicked', `${user.tag} (${user.id})`, [{ name:'By', value: interaction.user.tag }, { name:'Reason', value: reason }]);
  }
};
