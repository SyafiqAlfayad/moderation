const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../../utils/embed');
module.exports = {
  data: new SlashCommandBuilder().setName('avatar').setDescription('Show avatar').addUserOption(o=>o.setName('user').setDescription('Target')),
  async execute({ client, interaction }) {
    const user = interaction.options.getUser('user') || interaction.user;
    const embed = baseEmbed().setTitle(`${user.tag} Avatar`).setImage(user.displayAvatarURL({size:1024}));
    await interaction.reply({ embeds:[embed] });
  }
};
