const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../../utils/embed');
module.exports = {
  data: new SlashCommandBuilder().setName('serverinfo').setDescription('Show server info'),
  async execute({ client, interaction }) {
    const g = interaction.guild;
    const embed = baseEmbed().setTitle(`${g.name} Info`).addFields(
      { name:'Members', value: `${g.memberCount}`, inline:true },
      { name:'Owner', value: `<@${g.ownerId}>`, inline:true },
      { name:'ID', value:`${g.id}`, inline:true }
    );
    await interaction.reply({ embeds:[embed] });
  }
};
