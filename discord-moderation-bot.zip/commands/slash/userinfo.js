const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../../utils/embed');
module.exports = {
  data: new SlashCommandBuilder().setName('userinfo').setDescription('Show user info').addUserOption(o=>o.setName('user').setDescription('Target')),
  async execute({ client, interaction }) {
    const user = interaction.options.getUser('user') || interaction.user;
    const member = await interaction.guild.members.fetch(user.id).catch(()=>null);
    const embed = baseEmbed().setTitle(`${user.tag}`).setThumbnail(user.displayAvatarURL());
    if (member) embed.addFields({ name:'Joined', value: `${new Date(member.joinedTimestamp).toLocaleString()}` });
    embed.addFields({ name:'ID', value:`${user.id}` });
    await interaction.reply({ embeds:[embed] });
  }
};
