const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../../utils/embed');
module.exports = {
  data: new SlashCommandBuilder().setName('help').setDescription('Show help'),
  async execute({ client, interaction }) {
    const embed = baseEmbed().setTitle('Help').setDescription('Daftar perintah: /ban /kick /mute /unmute /warn /warnings /clear /slowmode /ping /userinfo /serverinfo /avatar /help');
    await interaction.reply({ embeds:[embed] });
  }
};
