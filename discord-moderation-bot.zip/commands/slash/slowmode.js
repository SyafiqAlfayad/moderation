const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../../utils/embed');
module.exports = {
  data: new SlashCommandBuilder().setName('slowmode').setDescription('Set slowmode (seconds)').addIntegerOption(o=>o.setName('seconds').setDescription('Seconds').setRequired(true)),
  async execute({ client, interaction }) {
    if (!interaction.member.permissions.has('ManageChannels')) return interaction.reply({ ephemeral:true, embeds:[baseEmbed().setTitle('Permission Denied').setDescription('Kamu tidak punya izin mengatur slowmode.')] });
    const seconds = Math.max(0, Math.min(21600, interaction.options.getInteger('seconds') || 0));
    await interaction.channel.setRateLimitPerUser(seconds);
    await interaction.reply({ embeds:[baseEmbed().setTitle('Slowmode Set').setDescription(`Slowmode diatur ke ${seconds} detik.`)] , ephemeral:true});
  }
};
