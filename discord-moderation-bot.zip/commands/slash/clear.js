const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../../utils/embed');
module.exports = {
  data: new SlashCommandBuilder().setName('clear').setDescription('Clear messages').addIntegerOption(o=>o.setName('amount').setDescription('Amount').setRequired(true)),
  async execute({ client, interaction }) {
    if (!interaction.member.permissions.has('ManageMessages')) return interaction.reply({ ephemeral:true, embeds:[baseEmbed().setTitle('Permission Denied').setDescription('Kamu tidak punya izin menghapus pesan.')] });
    const amount = Math.min(100, interaction.options.getInteger('amount')) || 10;
    const channel = interaction.channel;
    const deleted = await channel.bulkDelete(amount, true).catch(()=>null);
    await interaction.reply({ embeds:[baseEmbed().setTitle('Cleared').setDescription(`Dihapus: ${deleted?.size || 0} pesan.`)] , ephemeral:true});
  }
};
