const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
const { baseEmbed } = require('../../utils/embed');
const { ms } = require('../../utils/time');
const { sendModLog } = require('../../utils/modlog');

const mutesPath = './database/mutes.json';
let mutes = {};
if (fs.existsSync(mutesPath)) mutes = JSON.parse(fs.readFileSync(mutesPath));

module.exports = {
  data: new SlashCommandBuilder().setName('mute').setDescription('Mute a user').addUserOption(o=>o.setName('user').setDescription('Target').setRequired(true)).addStringOption(o=>o.setName('duration').setDescription('Duration')).addStringOption(o=>o.setName('reason').setDescription('Reason')),
  async execute({ client, interaction }) {
    if (!interaction.member.permissions.has('ModerateMembers')) return interaction.reply({ ephemeral:true, embeds:[baseEmbed().setTitle('Permission Denied').setDescription('Kamu tidak punya izin untuk mute.')] });
    const user = interaction.options.getUser('user');
    const member = interaction.guild.members.cache.get(user.id);
    const rawDuration = interaction.options.getString('duration') || client.config.defaultMuteDuration;
    const durationMs = ms(rawDuration);
    const reason = interaction.options.getString('reason') || 'No reason provided';
    if (!member) return interaction.reply({ ephemeral:true, embeds:[baseEmbed().setTitle('Not found').setDescription('Member tidak ditemukan.')] });

    let muteRole = interaction.guild.roles.cache.find(r => r.name === 'Muted');
    if (!muteRole) {
      muteRole = await interaction.guild.roles.create({ name: 'Muted', permissions: [] });
      for (const channel of interaction.guild.channels.cache.values()) {
        await channel.permissionOverwrites.edit(muteRole, { SendMessages:false, AddReactions:false, Speak:false });
      }
    }

    await member.roles.add(muteRole, reason);
    const until = durationMs ? Date.now() + durationMs : null;
    mutes[member.id] = { guildId: interaction.guild.id, until };
    fs.writeFileSync(mutesPath, JSON.stringify(mutes, null, 2));

    await interaction.reply({ embeds: [baseEmbed().setTitle('Muted').setDescription(`${user.tag} dibisukan.`).addFields({ name:'Duration', value: rawDuration }, { name:'Reason', value: reason })] });
    await sendModLog(interaction.guild, client, 'User Muted', `${user.tag} (${user.id})`, [{ name:'By', value: interaction.user.tag }, { name:'Duration', value: rawDuration }, { name:'Reason', value: reason }]);

    if (durationMs) setTimeout(async () => {
      try {
        const mem = await interaction.guild.members.fetch(member.id).catch(()=>null);
        if (mem) {
          await mem.roles.remove(muteRole, 'Auto unmute');
          delete mutes[member.id];
          fs.writeFileSync(mutesPath, JSON.stringify(mutes, null, 2));
          await sendModLog(interaction.guild, client, 'Auto Unmuted', `${user.tag} (${user.id})`, [{ name:'Reason', value: 'Mute duration expired' }]);
        }
      } catch(e){console.error(e);}
    }, durationMs);
  }
};
