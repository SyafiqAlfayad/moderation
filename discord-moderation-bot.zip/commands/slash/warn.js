const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
const { baseEmbed } = require('../../utils/embed');
const { sendModLog } = require('../../utils/modlog');

const warnsPath = './database/warns.json';
let warns = {};
if (fs.existsSync(warnsPath)) warns = JSON.parse(fs.readFileSync(warnsPath));

module.exports = {
  data: new SlashCommandBuilder().setName('warn').setDescription('Warn a user').addUserOption(o=>o.setName('user').setDescription('Target').setRequired(true)).addStringOption(o=>o.setName('reason').setDescription('Reason')),
  async execute({ client, interaction }) {
    if (!interaction.member.permissions.has('ManageMessages')) return interaction.reply({ ephemeral:true, embeds:[baseEmbed().setTitle('Permission Denied').setDescription('Kamu tidak punya izin memberi warning.')] });
    const user = interaction.options.getUser('user');
    const member = interaction.guild.members.cache.get(user.id);
    const reason = interaction.options.getString('reason') || 'No reason provided';
    if (!member) return interaction.reply({ ephemeral:true, embeds:[baseEmbed().setTitle('Not found').setDescription('Member tidak ditemukan.')] });

    if (!warns[member.id]) warns[member.id] = [];
    warns[member.id].push({ by: interaction.user.id, reason, time: Date.now() });
    fs.writeFileSync(warnsPath, JSON.stringify(warns, null, 2));

    await interaction.reply({ embeds: [baseEmbed().setTitle('Warned').setDescription(`${user.tag} telah diberi peringatan.`).addFields({ name:'Reason', value: reason })] });
    await sendModLog(interaction.guild, client, 'User Warned', `${user.tag} (${user.id})`, [{ name:'By', value: interaction.user.tag }, { name:'Reason', value: reason }]);
  }
};
