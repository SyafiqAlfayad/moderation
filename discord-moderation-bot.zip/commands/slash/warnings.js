const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
const { baseEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder().setName('warnings').setDescription('Show warnings').addUserOption(o=>o.setName('user').setDescription('Target')),
  async execute({ client, interaction }) {
    const warnsPath = './database/warns.json';
    const warns = fs.existsSync(warnsPath) ? JSON.parse(fs.readFileSync(warnsPath)) : {};
    const user = interaction.options.getUser('user') || interaction.user;
    const userWarns = warns[user.id] || [];
    if (!userWarns.length) return interaction.reply({ embeds:[baseEmbed().setTitle('No Warnings').setDescription(`${user.tag} tidak memiliki peringatan.`)], ephemeral:true });
    const embed = baseEmbed().setTitle('Warnings').setDescription(`${user.tag} memiliki ${userWarns.length} peringatan.`);
    for (let i=0;i<userWarns.length;i++){ const w=userWarns[i]; embed.addFields({ name:`#${i+1}`, value:`By: <@${w.by}> | Reason: ${w.reason} | ${new Date(w.time).toLocaleString()}` }); }
    await interaction.reply({ embeds:[embed] });
  }
};
