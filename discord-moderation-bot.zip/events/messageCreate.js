const config = require('../config.json');
const { baseEmbed } = require('../utils/embed');
const { handleMessage } = require('../utils/automod');

module.exports = {
  name: 'messageCreate',
  async execute(client, message) {
    try { await handleMessage(client, message); } catch (e) { console.error('AutoMod error', e); }
    if (message.author.bot || !message.guild) return;
    const prefix = config.prefix || '!';
    if (!message.content.startsWith(prefix)) return;
    const args = message.content.slice(prefix.length).trim().split(/ +/g);
    const commandName = args.shift().toLowerCase();
    const command = client.prefixCommands.get(commandName);
    if (!command) return;
    try {
      await command.execute({ client, message, args, baseEmbed });
    } catch (err) {
      console.error(err);
      const embed = baseEmbed().setTitle('Error').setDescription('Terjadi kesalahan saat menjalankan perintah.');
      message.reply({ embeds: [embed] });
    }
  }
};
