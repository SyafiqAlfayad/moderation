module.exports = {
  name: 'interactionCreate',
  async execute(client, interaction) {
    if (!interaction.isChatInputCommand()) return;
    const command = client.commands.get(interaction.commandName);
    if (!command) return;
    try {
      await command.execute({ client, interaction });
    } catch (err) {
      console.error(err);
      if (interaction.replied || interaction.deferred) {
        interaction.followUp({ content: 'Terjadi kesalahan saat menjalankan perintah (slash).', ephemeral: true });
      } else {
        interaction.reply({ content: 'Terjadi kesalahan saat menjalankan perintah (slash).', ephemeral: true });
      }
    }
  }
};
